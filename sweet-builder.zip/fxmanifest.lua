fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Senin İsmin'
description 'FiveM QBCore İnşaat Mesleği Scripti'
version '1.0.0'

shared_scripts {
    'config.lua'
}

server_scripts {
    '@qb-core/server/main.lua',
    'server/server.lua'
}

client_scripts {
    '@qb-core/client/main.lua',
    'client/client.lua'
}

dependencies {
    'qb-core',
    'qb-target'
}
