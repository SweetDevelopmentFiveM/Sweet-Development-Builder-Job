Config = {}

Config.JobName = "construction"

Config.NPCLocation = vector3(-509.38, -1001.47, 23.55)
Config.NPCHeading = 180.0

Config.JobSites = {
    {x = -509.38, y = -1001.47, z = 23.55} -- İnşaat sahası
}

Config.Materials = {
    {name = 'cement', label = 'Çimento', price = 50},
    {name = 'bricks', label = 'Tuğla', price = 30},
    {name = 'iron', label = 'Demir', price = 70}
}
