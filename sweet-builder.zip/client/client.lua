QBCore = exports['qb-core']:GetCoreObject()
local onJob = false -- Oyuncu işe girdiyse true olacak
local nailsCompleted = 0 -- Çakılan çivi sayısı
local workVehicle = nil -- İşçi aracı (Artık tek bir araç olacak)
local workBlip = nil -- İnşaat Alanı Blipi
local activeWorkSpot = nil -- Şu an aktif olan çivi çakma noktası
local activeMarker = nil -- Mor marker objesi

local payPerNail = 800 -- Çivi başına kazanılan para

local workLocation = vector3(-1092.63, -1648.48, 4.40) -- GPS noktası
local workSpots = {
    vector3(-1092.18, -1649.76, 7.44),
    vector3(-1097.04, -1652.94, 7.44),
    vector3(-1089.51, -1653.75, 7.44)
}

-- **İşe Başlama Engelleme ve NPC**
CreateThread(function()
    local blip = AddBlipForCoord(-509.38, -1001.47, 23.55)
    SetBlipSprite(blip, 566)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, 0.8)
    SetBlipColour(blip, 47)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("İnşaat Mesleği")
    EndTextCommandSetBlipName(blip)

    -- NPC oluşturma
    local model = GetHashKey("s_m_m_dockwork_01")
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(500)
    end

    local npc = CreatePed(4, model, -509.38, -1001.47, 22.55, 180.0, false, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    FreezeEntityPosition(npc, true)

    exports['qb-target']:AddTargetEntity(npc, {
        options = {
            {
                event = 'construction:requestJoinJob',
                icon = 'fas fa-hard-hat',
                label = 'İnşaat İşine Başla'
            },
            {
                event = 'construction:requestLeaveJob',
                icon = 'fas fa-door-open',
                label = 'İnşaat İşinden Ayrıl'
            }
        },
        distance = 2.0
    })
end)

-- **İşten Ayrılınca Para Verme (Çivi Sayısını Sunucuya Doğru Gönderme)**
RegisterNetEvent('construction:requestLeaveJob')
AddEventHandler('construction:requestLeaveJob', function()
    if not onJob then
        QBCore.Functions.Notify("Zaten işte değilsin!", "error")
        return
    end

    -- **Kazanç hesaplama ve sunucuya doğru çivi sayısını gönderme**
    TriggerServerEvent('construction:leaveJob', nailsCompleted)  

    -- **Araç silme**
    if workVehicle and DoesEntityExist(workVehicle) then
        DeleteEntity(workVehicle)
        workVehicle = nil
    end

    -- **Blip silme**
    if workBlip then
        RemoveBlip(workBlip)
        workBlip = nil
    end

    -- **Marker silme**
    if activeMarker and DoesEntityExist(activeMarker) then
        DeleteEntity(activeMarker)
        activeMarker = nil
    end

    onJob = false
    activeWorkSpot = nil
    nailsCompleted = 0 -- Çakılan çivi sayısını sıfırla

    QBCore.Functions.Notify("İşten ayrıldın! Ödemen hesaplanıyor...", "success")
end)

-- **İşe Başlama (Tekrar İşe Başlamayı Engelleme ve Araç Kontrolü)**
RegisterNetEvent('construction:requestJoinJob')
AddEventHandler('construction:requestJoinJob', function()
    if onJob then
        QBCore.Functions.Notify("Zaten iştesin! Önce işten ayrılmalısın.", "error")
        return
    end
    TriggerServerEvent('construction:joinJob') -- Server tarafında iş atanacak
    Wait(1000)
    TriggerEvent('construction:startTasks')
end)

-- **İşten Çıkınca Araç, Blip ve Marker Silme**
RegisterNetEvent('construction:requestLeaveJob')
AddEventHandler('construction:requestLeaveJob', function()
    if not onJob then
        QBCore.Functions.Notify("Zaten işte değilsin!", "error")
        return
    end

    -- **Araç silme**
    if workVehicle and DoesEntityExist(workVehicle) then
        DeleteEntity(workVehicle)
        workVehicle = nil
        print("🚗 İşçi aracı silindi!")
    end

    -- **Blip silme**
    if workBlip then
        RemoveBlip(workBlip)
        workBlip = nil
        print("📍 'İnşaat Alanı' blipi kaldırıldı!")
    end

    -- **Marker silme**
    if activeMarker and DoesEntityExist(activeMarker) then
        DeleteEntity(activeMarker)
        activeMarker = nil
    end

    onJob = false
    activeWorkSpot = nil
    QBCore.Functions.Notify("İşten ayrıldın!", "error")
    TriggerServerEvent('construction:leaveJob')
end)

-- **İşe Başlayınca Tek Araç Spawn Etme ve Blip Ekleme**
RegisterNetEvent('construction:startTasks')
AddEventHandler('construction:startTasks', function()
    onJob = true
    nailsCompleted = 0

    -- **Eğer araç varsa, yeni araç spawn etme**
    if workVehicle and DoesEntityExist(workVehicle) then
        QBCore.Functions.Notify("Zaten bir işçi aracın var!", "error")
    else
        local vehicleModel = GetHashKey("bison")
        RequestModel(vehicleModel)
        while not HasModelLoaded(vehicleModel) do
            Wait(500)
        end
        workVehicle = CreateVehicle(vehicleModel, -510.0, -1005.0, 23.0, 180.0, true, false)
        SetVehicleNumberPlateText(workVehicle, "WORKER")
        TaskWarpPedIntoVehicle(PlayerPedId(), workVehicle, -1)
    end

    SetNewWaypoint(workLocation.x, workLocation.y)

    workBlip = AddBlipForCoord(workLocation.x, workLocation.y, workLocation.z)
    SetBlipSprite(workBlip, 566)
    SetBlipDisplay(workBlip, 4)
    SetBlipScale(workBlip, 0.9)
    SetBlipColour(workBlip, 1)
    SetBlipAsShortRange(workBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("İnşaat Alanı")
    EndTextCommandSetBlipName(workBlip)

    QBCore.Functions.Notify("İşe başladın! Aracına bin ve inşaat alanına git!", "success")

    TriggerEvent('construction:addRandomWorkSpot')
end)

-- Rastgele bir çivi çakma noktası seçme
RegisterNetEvent('construction:addRandomWorkSpot')
AddEventHandler('construction:addRandomWorkSpot', function()
    if onJob then
        activeWorkSpot = workSpots[math.random(1, #workSpots)]
    end
end)

-- **Çivi Çakma Noktalarına Marker ve Yazı Ekleme (Para Bug Fix)**
CreateThread(function()
    while true do
        Wait(0)
        if onJob and activeWorkSpot then
            DrawMarker(29, activeWorkSpot.x, activeWorkSpot.y, activeWorkSpot.z + 0.2, 0, 0, 0, 0, 0, 0, 0.5, 0.5, 0.5, 120, 0, 255, 150, false, false, 2, false, nil, nil, false)
            
            local playerCoords = GetEntityCoords(PlayerPedId())
            local distance = #(playerCoords - activeWorkSpot)

            if distance < 1.5 then
                DrawModernText3D(activeWorkSpot.x, activeWorkSpot.y, activeWorkSpot.z + 1.0, "~b~[E]~w~ Çivi Çak")

                if IsControlJustReleased(0, 38) and not isNailing then
                    isNailing = true -- Çivi çakma işlemi başladı, tekrar basmayı engelle
                    TriggerEvent('construction:completeTask')
                end
            end
        end
    end
end)

-- **Çivi Çakma İşlemi (Para Bug Fix)**
RegisterNetEvent('construction:completeTask')
AddEventHandler('construction:completeTask', function()
    if onJob and activeWorkSpot then
        TaskStartScenarioInPlace(PlayerPedId(), "WORLD_HUMAN_HAMMERING", 0, true)
        
        Wait(5000) -- Çivi çakma süresi
        ClearPedTasks(PlayerPedId())

        nailsCompleted = nailsCompleted + 1
        QBCore.Functions.Notify("Çivi başarıyla çakıldı! İşten ayrılıp paranı almak istersen işe başladığın adamın yanına dön.", "success")

        isNailing = false -- Çivi çakma işlemi tamamlandı, tekrar basılabilir

        TriggerEvent('construction:addRandomWorkSpot')
    end
end)

-- **3D Modern Yazı (Arka Plan Karanlık)**
function DrawModernText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        -- Arka Plan Çiz
        local width = string.len(text) * 0.005
        DrawRect(_x, _y + 0.0125, width, 0.025, 0, 0, 0, 150) -- Siyah Arka Plan

        -- Yazıyı Çiz
        SetTextScale(0.45, 0.45)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 255)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end