QBCore = exports['qb-core']:GetCoreObject()

-- İşe girme
RegisterNetEvent('construction:joinJob')
AddEventHandler('construction:joinJob', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if not Player then
        print("[ERROR] Player bulunamadı! (source: " .. tostring(src) .. ")")
        return
    end

    Player.Functions.SetJob("construction")
    TriggerClientEvent('QBCore:Notify', src, "İşe Başladın! Görev yerlerin haritada işaretlendi!", "success")
    TriggerClientEvent('construction:startTasks', src)
    print("[DEBUG] " .. GetPlayerName(src) .. " inşaat işine başladı!")
end)

RegisterNetEvent('construction:leaveJob')
AddEventHandler('construction:leaveJob', function(nailsCompleted)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local payPerNail = 800 -- Çivi başına ödeme

    -- **Kazanç hesaplama (Hata önleme için varsayılan değerler eklendi)**
    local totalPay = (tonumber(nailsCompleted) or 0) * payPerNail  

    if Player then
        if totalPay > 0 then
            Player.Functions.AddMoney('cash', totalPay) -- Para envantere (cash) ekleniyor
            TriggerClientEvent('QBCore:Notify', src, "İşten ayrıldın ve $" .. totalPay .. " kazandın!", "success")
        else
            TriggerClientEvent('QBCore:Notify', src, "Çivi çakmadığın için ödeme almadın!", "error")
        end
    end
end)


    RegisterNetEvent('construction:leaveJob')
    AddEventHandler('construction:leaveJob', function(totalPay)
        local src = source
        local Player = QBCore.Functions.GetPlayer(src)
    
        if Player then
            Player.Functions.AddMoney('cash', totalPay)
            TriggerClientEvent('QBCore:Notify', src, "İşten ayrıldın ve $" .. totalPay .. " kazandın!", "success")
        end
    end)
    
